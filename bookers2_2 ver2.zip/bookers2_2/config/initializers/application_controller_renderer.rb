# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '485777e9acad437047b14a509d4fb65789eef61d93d00fc2f8e6807d18e490f0ea4c1e17db05d66765a2237dde327b4b1abe472132b86966ff037d3745cccfc4'