class UsersController < ApplicationController
  before_action :is_matching_login_user, only: [:edit, :update]

  def new
    @book = Book.new
  end

  def index
    @users = User.all
    @user = User.find(current_user.id)
    @books = Book.all
    @book = Book.new
  end

  def show
    @user = User.find(params[:id])
    @user_id = current_user.id
    @books = @user.books
    @book = Book.new

  end

  def edit
    @user = User.find(params[:id])
    @books = @user.books

  end

  def update
     @user = User.find(params[:id])
    if @user.update(user_params)
      flash[:notice] = "You have updated user successfully!"
      redirect_to "/users/#{current_user.id}"
    else
      render :edit
    end
  end


private

  def book_params
    params.require(:book).permit(:title, :body)
  end

  def user_params
    params.require(:user).permit(:name, :introduction, :profile_image)
  end

  def is_matching_login_user
    user = User.find(params[:id])
    unless user.id == current_user.id
      redirect_to user_path(current_user)
    end
  end
end
